# Set up

## Installation and Setup
1) Clone the repository to a local directory:
```
git clone https://github.com/WPI-SoftRobotics/srl-teleoperation.git
```

2) Follow the instructions here (under Build) to install ROS dependencies and clone the ros_kortex repo https://github.com/Kinovarobotics/ros_kortex

3) Clone the required joystick_drivers repository inside the newly cloned srl-teleoperation repository:
```
git clone https://github.com/ros-drivers/joystick_drivers.git
```

4) Return to the top directory and build the catkin workspace:
```
cd ..
catkin_make
```

5) Source the workspace setup file:
```
source devel/setup.bash
```

# Jaco Robot Simulation

## Launch File
Launch the kortex driver (connection to arm over ethernet):
```
roslaunch mocap_interface jaco3_launch.launch
```

## Run Nodes Separately
Launch gazebo with the kinova robot:
```
roslaunch mocap_interface jaco3_visualize.launch
```

Run the kinematics engine node for converting end-effector velocities to joint velocities:
```
rosrun mocap_interface jaco_kinematics.py
```

Run the node for managing Gazebo objects:
```
rosrun mocap-interface prop_manager.py
```

Run the node for calculating and sending end-effector velocities:
```
rosrun mocap_interface path_planner.py
```

Run the node for connecting to external joystick:
```
rosrun joy joy_node _dev_name:="Sony Interactive Entertainment Wireless Controller"
```

Run a pick-and-place example:
```
rosrun mocap-interface run_robot.py
```

# Motion Capture Hardware

## Include Motion Capture Hardware
Run node for connecting to mocap (change serial port as necessary):
```
rosrun rosserial_arduino serial_node.py /dev/ttyACM0
```

Run mocap driver node:
```
rosrun mocap_interface mocap_driver.py
```

Run glove driver node:
```
rosrun mocap_interface glove_driver.py
```

Run gripper driver node:
```
rosrun mocap_interface gripper_driver.py
```

## Software Stack
There is currently no dedicated launch file to bring up both the robot and control software.
The software stack must be brought up manually node-by-node as described above.

# Environment Sensing

## AprilTags
Scale up new tags from their 10px x 10px size if needed.
1 mm = 3.7795 pixels
1850% -> 49mm x 49mm
3780% -> 100mm x 100mm
```
convert ~/srl-teleoperation/src/apriltag-imgs/tag36h11/tag36_11_00000.png -scale 1850% tag36_11_000.png
```

Calibrate the webcam to be used for AprilTag detection
```
rosrun camera_calibration cameracalibrator.py --size 8x6 --square 0.026 image:=/camera/image_raw camera:=/camera
```
